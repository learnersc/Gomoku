package wuziqi;

public class Chessman {
	private int row, col;
	private boolean black;

	public Chessman(int row, int col, boolean black) {
		super();
		this.row = row;
		this.col = col;
		this.black = black;
	}

	public Chessman(int row, int col) {
		super();
		this.row = row;
		this.col = col;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getCol() {
		return col;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public boolean isBlack() {
		return black;
	}

	public void setBlack(boolean black) {
		this.black = black;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Chessman)) {
			return false;
		}
		Chessman target = (Chessman) obj;
		if (this.row == target.row && this.col == target.col) {
			return true;
		}
		return false;
	}
}
