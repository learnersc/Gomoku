package wuziqi;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

public class GamePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6601827825142085430L;
	public static final int WIDTH = 600;
	public static final int COUNT = 15;
	private float space = WIDTH / (COUNT + 1);

	private String prompt = null;
	private Font font = null;
	// ��ǰ�û���ִ��������ɫ
	private boolean black;
	// �����Ƿ��ֵ���ǰ�û�����
	private boolean self;

	private Chessman virtual;

	private Chessman[][] data = new Chessman[COUNT][COUNT];

	private MainFrame mf;

	private MouseMotionListener mml = new MouseMotionListener() {

		@Override
		public void mouseDragged(MouseEvent e) {
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			// if (!self) {
			// virtual = null;
			// return;
			// }
			int x = e.getX(), y = e.getY();
			int row, col;
			col = Math.round(x / space) - 1;
			row = Math.round(y / space) - 1;
			if (col < 0 || row < 0 || col > 14 || row > 14) {
				virtual = null;
				return;
			}
			// �ж����ָ���ƶ���λ�ô��Ƿ��������
			if (data[row][col] != null) {
				virtual = null;
				return;
			}

			Ellipse2D circle = new Ellipse2D.Float();
			circle.setFrameFromCenter((col + 1) * space, (row + 1) * space, (col + 1) * space + space / 2,
					(row + 1) * space + space / 2);
			if (circle.contains(x, y)) {
				virtual = new Chessman(row, col);
			} else {
				virtual = null;
			}
			repaint();
		}

	};

	// ��������
	private MouseListener ml = new MouseAdapter() {

		public void mouseClicked(MouseEvent e) {
			if (virtual != null) {
				// ���Ƹ�����
				virtual.setBlack(black);
				data[virtual.getRow()][virtual.getCol()] = virtual;
				// ������Ϣ
				Utils.getInstance().sendMsg(
						"wzq:3:" + virtual.getRow() + ":" + virtual.getCol() + ":" + (black ? 0 : 1), mf.targetAddress);
				// �ı�״̬
				self = !self;

				// ����Ƿ���Ӯ
				checkWin(virtual.getRow(), virtual.getCol());
				virtual = null;
				repaint();

			}
		}

	};

	public GamePanel(MainFrame mf) {
		this.mf = mf;
		super.setPreferredSize(new Dimension(600, 600));
		super.setBackground(new Color(160, 120, 90));
		font = new Font("����", Font.BOLD | Font.ITALIC, 40);
		prompt = "δ��ʼ��Ϸ";
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		//
		Graphics2D g2d = (Graphics2D) g;
		// ��������
		Line2D line = new Line2D.Float();
		float x1, y1, x2, y2;
		for (int i = 0; i < COUNT; i++) {
			// ���ƺ���
			x1 = space;
			y1 = (i + 1) * space;
			x2 = COUNT * space;
			y2 = y1;
			line.setLine(x1, y1, x2, y2);
			g2d.draw(line);
			// ��������
			x1 = (i + 1) * space;
			y1 = space;
			x2 = x1;
			y2 = COUNT * space;
			line.setLine(x1, y1, x2, y2);
			g2d.draw(line);
		}
		// ��������
		float x, y;
		Ellipse2D circle = new Ellipse2D.Float();

		RadialGradientPaint rgp;
		for (Chessman[] array : data) {
			for (Chessman cm : array) {
				if (cm == null)
					continue;
				y = (cm.getRow() + 1) * space;
				x = (cm.getCol() + 1) * space;

				circle.setFrameFromCenter(x, y, x + space / 2, y + space / 2);

				// �����������ĵ�
				Point2D point = new Point2D.Float(x - 6, y - 6);
				if (cm.isBlack()) {
					rgp = new RadialGradientPaint(point, 6f, new float[] { 0, 1 },
							new Color[] { Color.WHITE, Color.BLACK });
				} else {
					rgp = new RadialGradientPaint(point, 25f, new float[] { 0, 1 },
							new Color[] { Color.LIGHT_GRAY, Color.WHITE });
				}
				g2d.setPaint(rgp);
				g2d.fill(circle);
			}
		}

		// ������ʾ�ı�
		if (prompt != null) {
			g2d.setFont(font);
			g2d.setColor(Color.CYAN);
			g2d.drawString(prompt, 100, 280);
		}
		// �������������
		if (virtual != null) {
			g2d.setColor(Color.LIGHT_GRAY);
			circle.setFrameFromCenter((virtual.getCol() + 1) * space, (virtual.getRow() + 1) * space,
					(virtual.getCol() + 1) * space + space / 2, (virtual.getRow() + 1) * space + space / 2);
			g2d.fill(circle);
		}
	}

	public void enterGameStatus(boolean black) {
		this.prompt = null;
		this.black = black;
		this.self = black;
		// ��������ƶ�����
		this.addMouseMotionListener(mml);
		this.addMouseListener(ml);
		this.repaint();
	}

	public void leaveGameStatus(boolean black) {
		this.mf.gameOver();
		this.prompt = "��Ϸ����,"+(black?"�ڷ�":"�׷�")+"Ӯ��!";
		// ��������ƶ�����
		this.removeMouseMotionListener(mml);
		this.removeMouseListener(ml);
		this.repaint();
	}

	public void addChessman(int row, int col, boolean b) {
		Chessman cm = new Chessman(row, col, b);
		data[row][col] = cm;
		self = !self;
		repaint();
		// �����Ӯ
		checkWin(row, col);
	}

	public void checkWin(int row, int col) {
		new Thread() {
			public void run() {
				boolean black = data[row][col].isBlack();
				int count = 1;
				// ����
				for (int i = col - 1; i >= 0; i--) {
					if (data[row][i] == null || data[row][i].isBlack() != black) {
						break;
					}
					count++;
				}
				for (int i = col + 1; i < COUNT; i++) {
					if (data[row][i] == null || data[row][i].isBlack() != black) {
						break;
					}
					count++;
				}
				if (count >= 5) {
					// ��Ϸ����
					leaveGameStatus(black);
					return;
				}
				// б��
				count = 1;
				for (int r = row - 1, c = col - 1; r >= 0 && c >= 0; r--, c--) {
					if (data[r][c] == null || data[r][c].isBlack() != black) {
						break;
					}
					count++;
				}
				for (int r = row + 1, c = col + 1; r < COUNT && c < COUNT; r++, c++) {
					if (data[r][c] == null || data[r][c].isBlack() != black) {
						break;
					}
					count++;
				}
				if (count >= 5) {
					// ��Ϸ����
					leaveGameStatus(black);
					return;
				}
			}
		}.start();
	}
}
