package wuziqi;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1237752318737930277L;

	private DatagramSocket soc;
	private GamePanel gamePanel;
	private ControlPanel ctrlPanel;
	private boolean runningListener = true;
	public InetAddress targetAddress;

	// 0--δ��ʼ��1--��Ϸ�У�2--�ѽ���
	private int gameStatus;
	private WindowListener wl = new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			int result = JOptionPane.showConfirmDialog(null, "���Ҫ�˳���Ϸ��?");
			if (result == JOptionPane.OK_OPTION) {
				if (soc != null)
					soc.close();
				System.exit(0);
			}
		}
	};

	private Thread lsrThread = new Thread() {
		public void run() {
			byte[] array = new byte[1024];
			DatagramPacket pkt = new DatagramPacket(array, array.length);
			try {
				while (true) {
					soc.receive(pkt);
					// ������Ϣ
					String msg = new String(pkt.getData(), pkt.getOffset(), pkt.getLength(), "utf-8");
					handleMsg(msg, pkt.getAddress());
				}
			} catch (Exception e) {
			}
			System.out.println("�����߳̽�����...");
		}
	};

	protected void handleMsg(String msg, InetAddress address) {
		System.out.println("�յ���Ϣ:" + msg);

		String[] array = msg.split(":");
		if (array.length > 1) {
			if (array[0].equals("wzq")) {
				// ������Ϣidִ�в�ͬ�Ĳ���
				int flag = Integer.parseInt(array[1]);
				if (flag == 1) {
					// ���˷�������
					if (gameStatus == 1) {
						Utils.getInstance().sendMsg("wzq:2:0", address);
					} else {
						int result = JOptionPane.showConfirmDialog(null,
								"�Է�[" + address.getHostAddress() + "]����������Ϸ���Ƿ����?");
						if (result == JOptionPane.OK_OPTION) {
							// ��Ӧ����Ϸ
							Utils.getInstance().sendMsg("wzq:2:1", address);
							targetAddress = address;
							// ��ʼ��Ϸ.
							this.gameStatus = 1;
							this.gamePanel.enterGameStatus(false);
							this.ctrlPanel.enterGameStatus(false);
						} else {
							Utils.getInstance().sendMsg("wzq:2:0", address);
						}
					}
				} else if (flag == 2) {
					// �Է�������Ӧ��
					int v = Integer.parseInt(array[2]);
					if (v == 0) {
						JOptionPane.showMessageDialog(null, "�Է��ܾ����������!");
					} else {
						// ������Ϸ״̬
						this.gameStatus = 1;
						this.gamePanel.enterGameStatus(true);
						this.ctrlPanel.enterGameStatus(true);
						targetAddress = address;
					}
				} else if (flag == 3) {
					// ����
					int row = Integer.parseInt(array[2]);
					int col = Integer.parseInt(array[3]);
					int color = Integer.parseInt(array[4]);
					gamePanel.addChessman(row, col, color == 0 ? true : false);
				} else if (flag == 4) {
					// �Է�����
				}
			}
		}
	}

	public MainFrame() {
		super("������");
		super.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		gamePanel = new GamePanel(this);
		super.add(gamePanel);

		ctrlPanel = new ControlPanel();
		super.add(ctrlPanel, BorderLayout.EAST);

		super.pack();
		super.setResizable(false);
		super.setLocationRelativeTo(null);
		// ׷�Ӵ����¼�������
		super.addWindowListener(wl);
		// ���������߳�
		runningListener = startListener();
	}

	private boolean startListener() {
		boolean result = true;
		try {
			soc = new DatagramSocket(Utils.PORT);
			this.lsrThread.start();
		} catch (SocketException e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}

	public static void main(String[] args) {
		MainFrame mf = new MainFrame();
		if (mf.runningListener) {
			mf.setVisible(true);
		} else {
			JOptionPane.showMessageDialog(null, "�޷��󶨼����˿ڣ�");
			System.exit(0);
		}
	}

	public void gameOver() {
		this.ctrlPanel.gameOver();
	}

}
