package wuziqi;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Utils {

	public static final int PORT = 19999;

	private static Utils instance = new Utils();

	public static Utils getInstance() {
		return instance;
	}

	private DatagramSocket soc;

	public Utils() {
		try {
			soc = new DatagramSocket();
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ����udp��Ϣ
	 * 
	 * @param msg
	 * @param address
	 */
	public void sendMsg(String msg, InetAddress address) {
		if (msg == null || msg.length() == 0 || address == null) {
			return;
		}
		byte[] array;
		try {
			array = msg.getBytes("utf-8");
			DatagramPacket pkt = new DatagramPacket(array, 0, array.length, address, PORT);
			soc.send(pkt);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean isValidIp(String ip) {
		if (ip == null)
			return false;
		String regex = "([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
		return ip.matches(regex);
	}
}
