package wuziqi;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ControlPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -203413176568068343L;

	private JLabel lblStatus = new JLabel("��Ϸδ��ʼ!");
	private JTextField tfIp = null;
	private JButton btnReq = null;
	private JLabel lblColor = null;

	private ActionListener al = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == btnReq) {
				String ip = tfIp.getText().trim();
				if (ip.length() < 1) {
					lblColor.setText("������Է���IP��ַ!");
					return;
				}
				if (!Utils.getInstance().isValidIp(ip)) {
					lblColor.setText("�������IP��ַ��Ч!");
					return;
				}
				InetAddress address;
				try {
					address = InetAddress.getByName(ip);
					Utils.getInstance().sendMsg("wzq:1", address);
					lblColor.setText("�Ѿ���������!");
				} catch (UnknownHostException e1) {
					lblColor.setText("�������Ŀ���ַ��Ч!");
				}
			}
		}

	};

	public ControlPanel() {
		// ���ò�����������ֹ�����
		super.setLayout(new GridBagLayout());
		super.setPreferredSize(new Dimension(200, 600));
		super.setBackground(Color.GREEN);

		Font font = new Font("����", Font.BOLD, 32);
		lblStatus.setFont(font);
		lblStatus.setForeground(Color.ORANGE);
		super.add(lblStatus, getGBC(0, 0, 1, 1, 1, 0, GridBagConstraints.BOTH, GridBagConstraints.CENTER));

		JLabel lblIp = new JLabel("�Է�IP��ַ:");
		super.add(lblIp, getGBC(0, 1, 1, 1, 1, 0, GridBagConstraints.BOTH, GridBagConstraints.CENTER));

		tfIp = new JTextField(1);
		tfIp.setText("127.0.0.1");
		super.add(tfIp, getGBC(0, 2, 1, 1, 1, 0, GridBagConstraints.BOTH, GridBagConstraints.CENTER));

		btnReq = new JButton("����Է�");
		btnReq.addActionListener(al);
		super.add(btnReq, getGBC(0, 3, 1, 1, 1, 0, GridBagConstraints.NONE, GridBagConstraints.EAST));

		this.lblColor = new JLabel("", JLabel.LEFT);
		super.add(this.lblColor, getGBC(0, 4, 1, 1, 1, 0, GridBagConstraints.NONE, GridBagConstraints.EAST));

		JLabel lblTemp = new JLabel("��������Ϸxxx����");
		super.add(lblTemp, getGBC(0, 5, 1, 1, 1, 1, GridBagConstraints.NONE, GridBagConstraints.SOUTH));

	}

	private GridBagConstraints getGBC(int x, int y, int w, int h, int wx, int wy, int fill, int anchor) {
		Insets insets = new Insets(2, 2, 2, 2);
		GridBagConstraints gbc = new GridBagConstraints(x, y, w, h, wx, wy, anchor, fill, insets, 0, 0);
		return gbc;
	}

	public void enterGameStatus(boolean black) {
		lblStatus.setText("��Ϸ��!");
		lblColor.setText("����ִ" + (black ? "����" : "����"));
		this.tfIp.setEditable(false);
		this.btnReq.setEnabled(false);
	}

	public void gameOver() {
		lblStatus.setText("��Ϸ����!");
		lblColor.setText("");
		this.tfIp.setEditable(true);
		this.btnReq.setEnabled(true);
	}
}
